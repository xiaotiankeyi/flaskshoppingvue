<template>
  <div id="app">
      <!-- 路由占位符号 -->
      <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>

</style>
